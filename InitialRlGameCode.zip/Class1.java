// This is the main class, it initiates history (statistics) and begins a game

import java.util.*;
import java.io.*;

public class Class1 implements Common{
  static int metritis=0;

  // start logfile
  public static void saveStats(){
      history statistics=new history();
      statistics.writeToFile(Spiel.myStats.getText(),"stats" );
  }
  public static void main(String[] args) {
   for (int kk=0;kk<20;kk++){
      for (int i=0;i<1000;i++){
	  // play a game
        Spiel myGame=new Spiel(DIMBOARD,DIMBASE,NUMOFPAWNS);
        if ((i%10)==0)
        System.out.println(i);
      }
      saveStats();
      System.out.println("telos");
    }
  }

}





