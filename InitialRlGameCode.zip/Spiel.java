import java.util.*;
import java.io.*;
import java.awt.Color;
import java.awt.*;


//Spiel is ''game'' in german
public class Spiel implements Common{
    static NeuralNet whiteNeural; //neural net used for the 1st player
    static NeuralNet blackNeural; //neural net used for the 2nd player
    static Pawn[] whitePawn;
    static Pawn[] blackPawn;
    static Position myPosition;
    static TextArea myStats=new TextArea(); //used for the statistics
    static int inputSize=DIMBOARD*DIMBOARD-2*DIMBASE*DIMBASE+5; //abbreviation
    public Spiel(int dimBoard,int dimBase,int numOfPawns) {
      GameBoard myBoard=new GameBoard(dimBoard,dimBase);
      whitePawn=new Pawn[numOfPawns];
      blackPawn=new Pawn[numOfPawns];
      whiteNeural=new NeuralNet(1,2*inputSize,inputSize,1,0.95,0.5);
      blackNeural=new NeuralNet(2,2*inputSize,inputSize,1,0.95,0.5);
      Player whitePlayer=new Player(1);
      Player blackPlayer=new Player(2);
      for (int i=0;i<numOfPawns;i++){
        whitePawn[i]=new Pawn(i,true);
        blackPawn[i]=new Pawn(i,false);
      }
      myPosition=new Position(whitePawn,blackPawn);
      int counter=1; //so as not to let a game last forever, the maximum number of moves is 10000
      int[] whiteDesc=new int[2]; //not used, description of the move made
      int[] blackDesc=new int[2]; //not used, description of the move made
      boolean written=false;
      while ((myPosition.isFinal(whitePawn,blackPawn)==false)&&(counter<10000)){
        whiteDesc=whitePlayer.pickWhiteMove(whitePawn,GameBoard.mySquare);
        if (myPosition.isFinal(whitePawn,blackPawn)==false){
         blackDesc=blackPlayer.pickBlackMove(blackPawn,GameBoard.mySquare);
        } else {
                  written=true;
                  createStats(""+counter);
                  createStats("aspros");
               }
        counter++;
      }
      if ((counter<10000)&&(written==false)){
        createStats(""+ (--counter));
        createStats("mavros");
      }
      whiteNeural.storeWeights();
      blackNeural.storeWeights();
    }
    public void createStats(String s)
    {
        myStats.append(s);
        myStats.append("\n");

    }

}
