//records the result and the number of moves

import java.io.*;
import java.util.*;

public class history {
  File file;
  FileWriter out;
  public history() {
  }
  
  //creates the file, using the time the game started to name it
  final void writeToFile(String s,String name){
    Date myDate=new Date();
    String fileName=name;
    String helpName=myDate.toString();
    helpName=helpName.substring(11,19);
    helpName=helpName.replace(':',' ');
    fileName=helpName+fileName;
    fileName=fileName.concat(".txt");
    file=new File(fileName);
    try
    {
      out=new FileWriter(file);
      out.write(s);
      out.close();
    }
    catch (IOException e1)
    {
      System.out.println("tin katsame");
    }
  }
}
