// some standard values used throughout the programme

interface Common{
   static final int DIMBOARD=8;   // board size
   static final int DIMBASE=2;    // base size
   static final int NUMOFPAWNS=5; // easy to understand

}
