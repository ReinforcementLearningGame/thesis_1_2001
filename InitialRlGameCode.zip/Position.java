import java.util.*;
import java.io.*;

public class Position implements Cloneable,Common{
  private double currentWValue;
  private double currentBValue;
  private double currentWWInd;
  private double currentWBInd;
  private double currentBWInd;
  private double currentBBInd;
  private double[] whiteIndex;
  private double[] blackIndex;
  private int whiteRemaining;
  private int aux=0;
  private int blackRemaining;
  private double whitePawnId;
  private double blackPawnId;
  Pawn[] whitePawns;
  Pawn[] blackPawns;
  private Pawn[] cloneWhite=new Pawn[NUMOFPAWNS];
  private Pawn[] cloneBlack=new Pawn[NUMOFPAWNS];
  private Pawn[] sortWhite=new Pawn[NUMOFPAWNS];
  private Pawn[] sortBlack=new Pawn[NUMOFPAWNS];
  private Square[][] cloneSquare;
  private int xxx;private int yyy;
  public Position (Pawn[] wh_Pawns,Pawn[] bl_Pawns) {
    whitePawns=wh_Pawns;
    blackPawns=bl_Pawns;
    currentWValue=0;
    currentBValue=0;
    currentWWInd=0;
    currentWBInd=0;
    currentBWInd=0;
    currentBBInd=0;
  }
   
//check how many white pawns are still alive
   public final int getWhiteRemaining(Pawn[] helpPawns){
    whiteRemaining=0;
    for (int i=0;i<NUMOFPAWNS;i++){
       if (helpPawns[i].isAlive()) whiteRemaining++;
    }
    return whiteRemaining;
  }

//check how many black pawns are still alive
  public final int getBlackRemaining(Pawn[] helpPawns){
    blackRemaining=0;
    for (int i=0;i<NUMOFPAWNS;i++){
      if (helpPawns[i].isAlive()) blackRemaining++;
    }
    return blackRemaining;
  }

//get all legal moves for white player
  public final Square[][] getAllMovesForWhitePlayer(Square[][] outSquare){
    Square[][] helpSquare=new Square[NUMOFPAWNS][1];
    for (int i=0;i<NUMOFPAWNS;i++){
      helpSquare[i]=whitePawns[i].getLegitMovesForWhitePawn(outSquare);
    }
    return helpSquare;
  }

//get all legal moves for black player
  public final Square[][] getAllMovesForBlackPlayer(Square[][] outSquare){
    Square[][] helpSquare=new Square[NUMOFPAWNS][1];
    for (int i=0;i<NUMOFPAWNS;i++){
      helpSquare[i]=blackPawns[i].getLegitMovesForBlackPawn(outSquare);
    }
    return helpSquare;
  }

//check for winner
  public final boolean isFinal(Pawn[] wPawns,Pawn[] bPawns){
    boolean  answer=false;
    int whiteLeft=getWhiteRemaining(wPawns);
    int blackLeft=getBlackRemaining(bPawns);
    if ((whiteLeft==0)||(blackLeft==0))
      answer=true;
    else{
      for (int i=0;i<NUMOFPAWNS;i++){
        if (wPawns[i].isPawnInEnemyBase()){
          answer=true;
        }
        if (bPawns[i].isPawnInEnemyBase()) {
          answer=true;
        }
      }
    }
    return answer;
  }

//get the value occuring after playing the proposed move in a cloned board
  public final double[] getWValue(int pioni,Square tetr){
    int[] deadWhite;
    int[] deadBlack;
    deadWhite=new int[NUMOFPAWNS];
    deadBlack=new int[NUMOFPAWNS];
    Square dest=(Square)tetr.clone();
    for (int i=0;i<NUMOFPAWNS;i++){
      deadWhite[i]=0;
      deadBlack[i]=0;
    }

//clone the board
    cloneSquare=new Square[DIMBOARD][DIMBOARD];

//clone the pawns
    for (int i=0;i<NUMOFPAWNS;i++){
      cloneWhite[i]=(Pawn)whitePawns[i].clone();
      cloneWhite[i].position=(Square)whitePawns[i].position.clone();
      cloneBlack[i]=(Pawn)blackPawns[i].clone();
      cloneBlack[i].position=(Square)blackPawns[i].position.clone();
    }
    for (int i=0;i<DIMBOARD;i++){
      for (int j=0;j<DIMBOARD;j++){
        cloneSquare[i][j]=(Square)GameBoard.mySquare[i][j].clone();
      }
    }

//move the cloned pawn
    int kk=pioni;
    cloneWhite[kk].movePawn(cloneWhite[kk].position,cloneSquare[dest.xCoord][dest.yCoord]);
//check for dead
    for (int i=0;i<NUMOFPAWNS;i++){
      if ((cloneBlack[i].isAlive())&&(cloneBlack[i].isBlackPawnMovable(cloneSquare)==false)){
        deadBlack[i]=1;
      }
      if ((cloneWhite[i].isAlive())&&(cloneWhite[i].isWhitePawnMovable(cloneSquare)==false)){
        deadWhite[i]=1;
      }
    }
//kill dead pawns
    for (int i=0;i<NUMOFPAWNS;i++){
      if (deadBlack[i]==1){
        cloneBlack[i].killPawn();
      }
      if (deadWhite[i]==1){
        cloneWhite[i].killPawn();
      }
    }
//if we have a final state the reward is 1
/*SOS*/    if (Spiel.myPosition.isFinal(cloneWhite,cloneBlack)) {
            double[] ret=new double[1];ret[0]=1;
            return ret;
          }
    Spiel.whiteNeural.pawnsToInput(cloneWhite,cloneBlack);
    double[] ret;
//get value from neural net
    ret=Spiel.whiteNeural.Response();
    return ret;
  }

//the same as above
  public final double[] getBValue(int pioni,Square tetr){
    Square dest=tetr;
    int[] deadWhite;
    deadWhite=new int[NUMOFPAWNS];
    int[] deadBlack;
    deadBlack=new int[NUMOFPAWNS];
    for (int i=0;i<NUMOFPAWNS;i++){
      deadWhite[i]=0; 
      deadBlack[i]=0;
    }
    cloneSquare=new Square[DIMBOARD][DIMBOARD];
    for (int i=0;i<NUMOFPAWNS;i++){
      cloneWhite[i]=(Pawn)whitePawns[i].clone();
      cloneWhite[i].position=(Square)whitePawns[i].position.clone();
      cloneBlack[i]=(Pawn)blackPawns[i].clone();
      cloneBlack[i].position=(Square)blackPawns[i].position.clone();
    }
    for (int i=0;i<DIMBOARD;i++){
      for (int j=0;j<DIMBOARD;j++){
        cloneSquare[i][j]=(Square)GameBoard.mySquare[i][j].clone();
      }
    }
    cloneBlack[pioni].movePawn(cloneBlack[pioni].position,cloneSquare[dest.xCoord][dest.yCoord]);
    for (int i=0;i<NUMOFPAWNS;i++){
      if ((cloneWhite[i].isAlive())&&(cloneWhite[i].isWhitePawnMovable(cloneSquare)==false)){
        deadWhite[i]=1;
      }
      if ((cloneBlack[i].isAlive())&&(cloneBlack[i].isBlackPawnMovable(cloneSquare)==false)){
        deadBlack[i]=1;
      }
    }
    for (int i=0;i<NUMOFPAWNS;i++){
      if (deadWhite[i]==1){
        cloneWhite[i].killPawn();
      }
      if (deadBlack[i]==1){
        cloneBlack[i].killPawn();
      }
    }
/*SOS*/ if (Spiel.myPosition.isFinal(cloneWhite,cloneBlack)){
          double ret[]=new double[1];ret[0]=1;
          return ret;
        }
    Spiel.blackNeural.pawnsToInput(cloneWhite,cloneBlack);
    double[] ret;
    ret=Spiel.blackNeural.Response();
    return ret;

  }
  public final void refreshPosition(){
    int[] deadWhite;
    int[] deadBlack;
    deadWhite=new int[NUMOFPAWNS];
    deadBlack=new int[NUMOFPAWNS];
    for (int i=0;i<NUMOFPAWNS;i++){
      deadWhite[i]=0;
      deadBlack[i]=0;
    }
    for (int i=0;i<NUMOFPAWNS;i++){
      if ((blackPawns[i].isAlive())&&(blackPawns[i].isBlackPawnMovable(GameBoard.mySquare)==false)){
        deadBlack[i]=1;
        }
      if ((whitePawns[i].isAlive())&&(whitePawns[i].isWhitePawnMovable(GameBoard.mySquare)==false)){
        deadWhite[i]=1;
      }
    }
    for (int i=0;i<NUMOFPAWNS;i++){
      if (deadBlack[i]==1){
        blackPawns[i].killPawn();
      }
      if (deadWhite[i]==1){
        whitePawns[i].killPawn();
      }
    }

  }

  public final void setCurrentWValue(double timi){
    currentWValue=timi;
  }
  public final void setCurrentBValue(double timi){
    currentBValue=timi;
  }
  public final double getCurrentWValue(){
    return currentWValue;
  }
  public final double getCurrentBValue(){
    return currentBValue;
  }


  public final double getReward(boolean asprosCall){
    if (isFinal(whitePawns,blackPawns)==true) return 1; //final state reached
    if ((asprosCall)&&(canBlackWin())) return -1;       // black can win, so white's move is bad (losing)
    if ((!asprosCall)&&(canWhiteWin())) return -1;      // white can win, so black's move is bad (losing)
    return 0;

  }
  public final void setCurrentWInd(double whiteI,double blackI){
    currentWWInd=whiteI;
    currentWBInd=blackI;
  }
  public final double[] getCurrentWInd(){
    double[] aux=new double[2];
    aux[0]=currentWWInd;
    aux[1]=currentWBInd;
    return aux;
  }
  public final void setCurrentBInd(double whiteI,double blackI){
    currentBWInd=whiteI;
    currentBBInd=blackI;
  }
  public final double[] getCurrentBInd(){
    double[] aux=new double[2];
    aux[0]=currentBWInd;
    aux[1]=currentBBInd;
    return aux;
  }

//check if black can win after white's last move
  public final boolean canBlackWin(){
    Square[][] outSquare=new Square[DIMBOARD][DIMBOARD];
    for (int i=0;i<DIMBOARD;i++){
      for (int j=0;j<DIMBOARD;j++){
        outSquare[i][j]=(Square)GameBoard.mySquare[i][j].clone();
      }
    }
    Square[][] helpSquare=new Square[NUMOFPAWNS][1];
    helpSquare=getAllMovesForBlackPlayer(outSquare);
    for (int i=0;i<NUMOFPAWNS;i++)
      for (int j=0;j<2*DIMBASE;j++)
        if (helpSquare[i][j].isInWhiteBase()) return true;
    return false;
  }

//check if white can win after black's last move
  public final boolean canWhiteWin(){
    Square[][] outSquare=new Square[DIMBOARD][DIMBOARD];
    for (int i=0;i<DIMBOARD;i++){
      for (int j=0;j<DIMBOARD;j++){
        outSquare[i][j]=(Square)GameBoard.mySquare[i][j].clone();
      }
    }
    Square[][] helpSquare=new Square[NUMOFPAWNS][1];
    helpSquare=getAllMovesForWhitePlayer(outSquare);
    for (int i=0;i<NUMOFPAWNS;i++)
      for (int j=0;j<2*DIMBASE;j++)
        if (helpSquare[i][j].isInBlackBase()) return true;
    return false;
  }

}
